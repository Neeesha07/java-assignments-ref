package com.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@ToString
@Entity
@Data
@NoArgsConstructor
public class Blogs {

	@Id
	@GeneratedValue
	private int blogId;
	private String title;
	private String category;
	private String content;
	@JoinColumn(name="owner_id")
	@JsonBackReference
	@ManyToOne(cascade =CascadeType.ALL)
	private Owner owner;
	@JsonManagedReference
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "")
	private List<Comment> comments;

		public Blogs(String title, String category, String content) {
			super();
			this.title = title;
			this.category = category;
			this.content = content;
		}
}
