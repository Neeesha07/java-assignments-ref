package com.repo;

import org.springframework.data.repository.CrudRepository;

import com.entity.Blogs;
import com.entity.Owner;

public interface BlogRepository extends CrudRepository<Blogs, Integer> {

}
